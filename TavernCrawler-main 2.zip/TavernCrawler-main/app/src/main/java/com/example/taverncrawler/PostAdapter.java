package com.example.taverncrawler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {
    Context context;
    List<Post> posts;

    public PostAdapter(Context context,List<Post> posts) {
        this.context = context;
        this.posts = posts;
    }

    @NonNull
    @Override

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.post,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Post post = posts.get(position);
        holder.bind(post);

    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvbarname;
        TextView tvlocation;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvbarname = itemView.findViewById(R.id.tvBarname);
            tvlocation = itemView.findViewById(R.id.Lolcationtv);

        }

        public void bind(Post post) {
            tvbarname.setText(post.barname);
            tvlocation.setText(post.location);
        }
    }
}
