package com.example.taverncrawler;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class Post {
    public String barname;
    public String location;
    public int rating;

    public static Post fromJson(JSONObject jsonObject) throws JSONException{
        Post post = new Post();
        post.barname = jsonObject.getString();
        post.location = jsonObject.getString();
        post.rating = jsonObject.getInt();
        return post;
    }
    public static  List<Post>  fromJsonArray(JSONArray jsonArray) throws JSONException{
        List<Post> posts  = new ArrayList<>() ;
        for(int  i =0 ;  i < jsonArray.length();i++){
            posts.add(fromJson(jsonArray.getJSONObject(i)));
        }
        return posts;
    }
}
